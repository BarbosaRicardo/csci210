public class Tester
{
    public static void main()
    {
        //first shorter
        String first = "1";
        String second = "2147483647";

        //second shorter
        //String first = "2147483647";
        //String second = "1";

        //same length
        //String first = "2147483647";
        //String second = "2147483647";
        
        //you must write all of your code here
    }
}
