public interface BSTreeInterface<T>
{
    void insertBST(T item);
    
    T find(T item);
    
    String toString();
}
