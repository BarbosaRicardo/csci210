//declare WordCount comparable, but only to other WordCount objects
public class WordCount implements Comparable<WordCount>
{
    protected String word;
    protected int count;
    protected int list;

    public WordCount()
    {
        word = "";
        count = 0;
        list = 0;
    }

    public WordCount(String w)
    {
        word = w;
        count = 0;
        list = 0;
    }

    public int compareTo(WordCount other)
    {
        return word.compareTo(other.word);
    }

    public String toString()
    {
        return String.format("%-12s %3d %3d", word, count, list);
    }
}
