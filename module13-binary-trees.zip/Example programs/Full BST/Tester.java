public class Tester
{
    public static void main()
    {
        //create generic BST, of WordCount here
        BSTree<WordCount> t = new BSTree<WordCount>();

        t.insertBST(new WordCount("once"));
        t.insertBST(new WordCount("upon"));
        t.insertBST(new WordCount("a"));
        t.insertBST(new WordCount("time"));
        t.insertBST(new WordCount("in"));
        t.insertBST(new WordCount("the"));
        t.insertBST(new WordCount("west"));

        //print in alpha order
        System.out.println(t.toString());

        //search the tree
        if (t.find(new WordCount("time")) != null)
            System.out.println("time Found");

        if (t.find(new WordCount("east")) == null)
            System.out.println("east Not found");
    }
}
