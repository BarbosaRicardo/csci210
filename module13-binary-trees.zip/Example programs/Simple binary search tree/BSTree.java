public class BSTree
{
    private Node root;

    public BSTree()
    {
        root = null;
    }

    //WARNING: this method assumes that x does not appear in the bst
    //should call find() first to check this
    public void insertBST(int x)
    {
        if (root == null)
            root = new Node(x);
        else {
            Node lead, lag;
            lead = lag = root;
            while (lead != null) {
                lag = lead;
                if (x < lag.info)
                    lead = lag.left;
                else
                    lead = lag.right;
            }
            //lead fell off tree, lag is parent of new node
            if (x < lag.info)
                lag.left = new Node(x);
            else
                lag.right = new Node(x);
        }
    }

    public Node find(int x)
    {
        Node r = root;
        while (r != null && r.info != x) {
            if (r.info < x)
                r = r.right;
            else
                r = r.left;
        }
        return r;
    }
    
    private void pretrav(Node r)
    {
        if (r != null) {
            System.out.print(r.info + " ");
            pretrav(r.left);
            pretrav(r.right);
        }
    }

    public void preorder()
    {
        pretrav(root);
        System.out.println();
    }
//***do I want to explain that this could maybe be used for toString()??? 
    private void intrav(Node r)
    {
        if (r != null) {
            intrav(r.left);
            System.out.print(r.info + " ");
            intrav(r.right);
        }
    }

    public void inorder()
    {
        intrav(root);
        System.out.println();
    }

    private void posttrav(Node r)
    {
        if (r != null) {
            posttrav(r.left);
            posttrav(r.right);
            System.out.print(r.info + " ");
        }
    }

    public void postorder()
    {
        posttrav(root);
        System.out.println();
    }
}