public class Tester
{
    public static void main()
    {
        BSTree t = new BSTree();

        t.insertBST(20);
        t.insertBST(10);
        t.insertBST(18);
        t.insertBST(25);
        t.insertBST(23);
        t.insertBST(16);
        t.insertBST(15);

        t.preorder();

        t.inorder();

        t.postorder();

        if (t.find(16) != null)
            System.out.println("Found");

        if (t.find(24) == null)
            System.out.println("Not found");
    }
}
