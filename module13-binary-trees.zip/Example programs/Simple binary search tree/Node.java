public class Node
{
    protected int info;
    protected Node left;
    protected Node right;

    public Node()
    {
        info = 0;
        left = null;
        right = null;
    }

    public Node(int i)
    {
        info = i;
        left = null;
        right = null;
    }
}