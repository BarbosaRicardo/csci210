public class Node
{
    protected Comparable info;
    protected Node left;
    protected Node right;

    public Node()
    {
        info = 0;
        left = null;
        right = null;
    }

    public Node(Comparable obj)
    {
        info = obj;
        left = null;
        right = null;
    }
}