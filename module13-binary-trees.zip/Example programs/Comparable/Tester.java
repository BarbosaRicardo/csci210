public class Tester
{
    public static void main()
    {
        BSTree t = new BSTree();

        //insert some new words into the tree
        t.insertBST("once");
        t.insertBST("upon");
        t.insertBST("a");
        t.insertBST("time");
        t.insertBST("in");
        t.insertBST("the");
        t.insertBST("west");

        //print in alpha order
        t.inorder();

        //search the tree
        if (t.find("time") != null)
            System.out.println("time Found");

        if (t.find("east") == null)
            System.out.println("east Not found");
    }
}
