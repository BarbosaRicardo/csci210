public class Stack
{
    public static final int MAX = 9;

    private int element[];
    private int top;

    public Stack()
    {
        element = new int[MAX];
        top = -1;
    }
    
    //you must write the necessary Stack methods here
}
