public class Tester
{
    public static void main()
    {
        Stack s = new Stack();

        for (int x = 1; x < 6; ++x)
            s.push(x);

        while (!s.isEmpty())
            System.out.println(s.pop());

        //test empty stack error            
        s.pop();
    }
}
