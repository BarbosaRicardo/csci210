public class DoubleItem
{
    protected int info;
    protected DoubleItem next;
    protected DoubleItem prev;

    public DoubleItem()
    {
        info = 0;
        next = null;
        prev = null;
    }

    public DoubleItem(int i)
    {
        info = i;
        next = null;
        prev = null;
    }
}
