public class Tester
{
    public static void main()
    {
        DoubleList l = new DoubleList();

        for (int x = 1; x < 6; ++x)
            l.insertFirst(x);

        DoubleItem r = l.find(3);
        l.delete(r);
        r = l.find(2);
        l.insertBefore(r, 9);

        System.out.println("Count is: " + l.count());

        while (!l.isEmpty())
            System.out.println(l.removeFirst());

        System.out.println("done");
    }
}
