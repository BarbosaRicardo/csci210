public class DoubleList
{
    private DoubleItem list;

    public DoubleList()
    {
        list = null;
    }

    public void insertFirst(int i)
    {
        DoubleItem r = new DoubleItem(i);
        r.next = list;
        //if there's a next item, update its prev
        if (r.next != null)
            r.next.prev = r;
        list = r;
    }

    public int removeFirst()
    {
        if (isEmpty()) {
            System.out.println("Error in removeFirst(): list is empty");
            System.err.println("Error in removeFirst(): list is empty");
            System.exit(1);
        }
        DoubleItem r = list;
        int x = r.info;
        list = r.next;
        //if there is a first item, update its prev
        if (list != null)
            list.prev = null;
        return x;
    }

    public Boolean isEmpty()
    {
        return list == null;
    }

    public int count()
    {
        int count = 0;
        DoubleItem r = list;
        while (r != null) {
            ++count;
            r = r.next;
        }
        return count;
    }

    public void insertBefore(DoubleItem p, int i)
    {
        if (isEmpty() || p == null) {
            System.out.println("Error in insertBefore(): list is empty or p not set");
            System.err.println("Error in insertBefore(): list is empty or p not set");
            System.exit(2);
        }
        DoubleItem r = new DoubleItem(i);
        DoubleItem left = p.prev;   //left is previous item
        p.prev = r;
        r.next = p;
        r.prev = left;
        if (left == null)
            //then p is first item in list
            list = r;
        else
            left.next = r;
    }

    public int delete(DoubleItem p)
    {
        if (p == null) {
            System.out.println("Error in delete(): p not set");
            System.err.println("Error in delete(): p not set");
            System.exit(3);
        }
        int x = p.info;
        DoubleItem left = p.prev;    //left is previous item
        DoubleItem right = p.next;   //right is next item
        if (left == null)
            //we're deleting the first item from the list
            list = right;
        else
            left.next = right;
        if (right != null)
            //update the next item
            right.prev = left;
        return x;
    }

    //returns reference to first occurrence of i in list
    //returns null if not found
    public DoubleItem find(int i)
    {
        if (isEmpty()) {
            System.out.println("Error in find(): list is empty");
            System.err.println("Error in find(): list is empty");
            System.exit(4);
        }
        DoubleItem r = list;
        while (r != null && r.info != i)
            r = r.next;
        return r;
    }
}
