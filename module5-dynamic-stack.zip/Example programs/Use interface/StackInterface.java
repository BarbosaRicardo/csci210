public interface StackInterface
{
    void push(int i);

    int pop();

    boolean isEmpty();
}
