public class Tester
{
    public static void main()
    {
        //implement the interface s as a LinkedStack
        StackInterface s = new LinkedStack();

        for (int x = 1; x < 6; ++x)
            s.push(x);

        while (!s.isEmpty())
            System.out.println(s.pop());

        System.out.println("done");
    }
}
