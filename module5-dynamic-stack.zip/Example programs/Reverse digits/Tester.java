public class Tester
{
    public static void main()
    {
        String number = "12345";
        
        //you must write all your code here
    }
}
