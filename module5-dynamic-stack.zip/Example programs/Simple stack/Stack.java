public class Stack
{
    private Item top;

    public Stack()
    {
        top = null;
    }

    public void push(int i)
    {
        Item item = new Item(i);

        if (!isEmpty())
            item.next = top;

        top = item;
    }

    public int pop()
    {
        //assumes stack is not empty
        int temp = top.info;
        top = top.next;
        return temp;
    }

    public boolean isEmpty()
    {
        return top == null;
    }
}
