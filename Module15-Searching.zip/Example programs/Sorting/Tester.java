public class Tester
{
    public static void main()
    {
        //create a random array to sort
        int n = 10;    //number of items
        Sorting sortThis = new Sorting(n);
        
        //sort it - exchange sorts
        //sortThis.bubble(n);
        //sortThis.shaker(n);
        //sortThis.quick(0, (n - 1));
        
        //insertion sorts
        //sortThis.linear(n);
        //sortThis.binaryInsertion(n);
        //sortThis.shell(n);
        
        //selection sorts
        //sortThis.select(n);
        sortThis.heap(n);
        
        //print out sorted array
        System.out.println(sortThis.toString());
    }
}
