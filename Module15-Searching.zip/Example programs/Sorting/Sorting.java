import java.util.Random;

public class Sorting
{
    public static final int MAX = 100;

    private int list[];

    public Sorting(int n)
    {
        list = new int[n];

        //fill the array with n random numbers, 0..(MAX - 1) inclusive
        Random r = new Random();
        for (int i = 0; i < n; ++i)
            list[i] = r.nextInt(MAX);
    }

    //exchange sorts
    public void bubble(int n)
    {
        int temp;
        for (int i = 0; i < n - 1; i++)
            for (int j = i + 1; j < n; j++)
                if (list[i] > list[j]) {
                    temp = list[i];
                    list[i] = list[j];
                    list[j] = temp;
                }
    }

    public void shaker(int n)
    {
        int i, temp;

        int k = 1;
        int m = n - 1;
        int j = n - 1;
        do {
            for (i = m; i >= k; --i)
                if (list[i - 1] > list[i]) {
                    temp = list[i - 1];
                    list[i - 1] = list[i];
                    list[i] = temp;
                    j = i;
                }
            k = j + 1;
            for (i = k; i <= m; ++i)
                if (list[i - 1] > list[i]) {
                    temp = list[i - 1];
                    list[i - 1] = list[i];
                    list[i] = temp;
                    j = i;
                }
            m = j - 1;
        } while (k <= m);
    }

    public void quick(int first, int last)
    {
        int i = first;
        int j = last;
        int pivot = list[(first + last) / 2];
        int temp;
        do {
            while (list[i] < pivot)
                i = i + 1;
            while (list[j] > pivot)
                j = j - 1;
            if (i <= j) {
                temp = list[i];
                list[i] = list[j];
                list[j] = temp;
                i = i + 1;
                j = j - 1;
            }
        } while (i <=j);
        if (first < j)
            quick(first, j);
        if (i < last)
            quick(i, last);
    }

    //insertion sorts
    public void linear(int n)
    {
        int j, temp;

        for (int i = 1; i < n; i++) {
            temp = list[i];
            j = i - 1;
            while (j >= 0 && temp < list[j]) {
                list[j+1] = list[j];
                j = j - 1;
            }
            list[j+1] = temp;
        }
    }

    public void binaryInsertion(int n)
    {
        int i, j, left, right, middle, temp;

        for (i = 1; i < n; ++i) {
            temp = list[i];
            left = 0;
            right = i - 1;
            while (left <= right) {
                middle = (left + right) / 2;
                if (temp < list[middle])
                    right = middle - 1;
                else
                    left = middle + 1;
            }
            for (j = i - 1; j >= left; --j)
                list[j + 1] = list[j];
            list[left] = temp;
        }
    }

    public void shell(int n)
    {
        int temp;

        for (int incr = n / 2; incr > 0; incr = incr / 2)
            for (int i = incr; i < n; ++i)
                for (int j = i - incr; j >= 0 && list[j] > list[j + incr];
                j = j - incr) {
                    temp = list[j];
                    list[j] = list[j + incr];
                    list[j + incr] = temp;
                }
    }

    //selection sorts
    public void select(int n)
    {
        int i, j, k, temp;

        for (i = 0; i < n - 1; i++) {
            k = i;
            temp = list[i];
            for (j = i + 1; j < n; j++)
                if (list[j] < temp) {
                    k = j;
                    temp = list[j];
                }
            list[k] = list[i];
            list[i] = temp;
        }
    }

    public void heap(int n)
    {
        int temp;

        for (int i = n / 2; i >= 0; i--)
            buildheap(i, n - 1);
        for (int i = n - 1; i >= 1; i--) {
            temp = list[0];
            list[0] = list[i];
            list[i] = temp;
            buildheap(0, i - 1);
        }
    }

    private void buildheap(int root, int i)
    {
        int temp;
        int maxChild;
        Boolean isHeap = false;
        while ((root * 2 <= i) && !isHeap) {
            if (root * 2 == i)
                maxChild = root * 2;
            else if (list[root * 2] > list[root * 2 + 1])
                maxChild = root * 2;
            else
                maxChild = root * 2 + 1;

            if (list[root] < list[maxChild]) {
                temp = list[root];
                list[root] = list[maxChild];
                list[maxChild] = temp;
                root = maxChild;
            }
            else
                isHeap = true;
        }
    }

    public String toString()
    {
        StringBuilder sb = new StringBuilder("{");
        int i;
        for (i = 0; i < list.length - 1; ++i) {
            sb.append(list[i] + ", ");
        }
        sb.append(list[i] + "}");
        return sb.toString();
    }
}
