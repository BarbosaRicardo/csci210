public class Tester
{
    public static void main()
    {
        Factorial f = new Factorial();
        int val;
        
        val = f.fact(4);
        System.out.println(val);
    }
}