public class Tester
{
    public static void main()
    {
        List l = new List();

        for (int x = 1; x < 6; ++x)
            l.insertFirst(x);

        System.out.println("Count is: " + l.count());

        l.freeList();
        System.out.println("Count is: " + l.count());

        System.out.println("done");
    }
}
