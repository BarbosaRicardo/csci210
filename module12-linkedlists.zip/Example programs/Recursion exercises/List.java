public class List
{
    private Item list;

    public List()
    {
        list = null;
    }

    public void insertFirst(int i)
    {
        Item r = new Item(i);
        r.next = list;
        list = r;
    }

    public int recursiveCount(Item r)
    {
        if (r == null)
            return 0;
        return 1 + recursiveCount(r.next);
    }

    public void freeList()
    {
        if (list == null)
            return;
        list = list.next;
        freeList();
    }

    public int count()
    {
        return recursiveCount(list);
    }
}