public class Tester
{
    public static void main()
    {
        ListInterface<Character> l = new LinkedList<Character>();

        for (Character ch = 'A'; ch < 'F'; ++ch)
            l.insertFirst(ch);

        Item<Character> r = l.find('C');
        l.deleteAfter(r);
        l.insertAfter(r, 'Z');

        System.out.println("Count is: " + l.count());

        while (!l.isEmpty())
            System.out.println(l.removeFirst());

        //demonstrate exception handling
        try {
            System.out.println(l.removeFirst());
        }
        catch (ListEmptyException underflow) {
            System.out.println("Exception: " + underflow.getMessage());
            System.err.println("Exception: " + underflow.getMessage());
            System.exit(1);
        }


        System.out.println("done");
    }
}
