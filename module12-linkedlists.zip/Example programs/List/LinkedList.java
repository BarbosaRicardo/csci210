public class LinkedList<T> implements ListInterface<T>
{
    private Item<T> list;

    public LinkedList()
    {
        list = null;
    }

    public void insertFirst(T item)
    {
        Item<T> r = new Item<T>(item);
        r.next = list;
        list = r;
    }

    public T removeFirst() throws ListEmptyException
    {
        if (isEmpty()) {
            throw new ListEmptyException("In removeFirst() - list is empty");
        }
        Item<T> r = list;
        T x = r.info;
        list = r.next;
        return x;
    }

    public Boolean isEmpty()
    {
        return list == null;
    }

    public int count()
    {
        int count = 0;
        Item<T> r = list;
        while (r != null) {
            ++count;
            r = r.next;
        }
        return count;
    }

    public void insertAfter(Item<T> p, T t) throws ListEmptyException, ListNullPointerException
    {
        if (isEmpty())
            throw new ListEmptyException("In insertAfter() - list is empty");

        if (p == null)
            throw new ListNullPointerException("In insertAfter() - p is null");

        Item<T> r = new Item<T>(t);
        r.next = p.next;
        p.next = r;
    }

    public T deleteAfter(Item<T> p) throws ListNullPointerException
    {
        if (p == null || p.next == null)
            throw new ListNullPointerException("In deleteAfter() - p not set or is last item");

        Item<T> r = p.next;
        T x = r.info;
        p.next = r.next;
        return x;
    }

    public Item<T> find(T t) throws ListEmptyException
    {
        if (isEmpty())
            throw new ListEmptyException("In find() - list is empty");
        Item<T> r = list;
        while (r != null && r.info != t)
            r = r.next;
        return r;
    }
}
