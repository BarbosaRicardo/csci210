public class ListNullPointerException extends RuntimeException
{
    public ListNullPointerException()
    {
        super();    
    }

    public ListNullPointerException(String message)
    {
        super(message);    
    }
}