public interface ListInterface<T>
{
    void insertFirst(T item);

    T removeFirst() throws ListEmptyException;

    Boolean isEmpty();

    int count();

    void insertAfter(Item<T> p, T item) throws ListEmptyException, ListNullPointerException;

    T deleteAfter(Item<T> p) throws ListNullPointerException;

    Item<T> find(T item) throws ListEmptyException;
}