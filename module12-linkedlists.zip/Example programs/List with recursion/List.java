public class List
{
    private Item list;

    public List()
    {
        list = null;
    }

    public void insertFirst(int i)
    {
        Item r = new Item(i);
        r.next = list;
        list = r;
    }
    
    public void recursivePrint(Item r)
    {
        if (r != null) {
            System.out.print(r.info + " ");
            recursivePrint(r.next);
        }
    }
    
    public void println()
    {
        recursivePrint(list);
        System.out.println();
    }

    public void reverseRecursivePrint(Item r)
    {
        if (r != null) {
            reverseRecursivePrint(r.next);
            System.out.print(r.info + " ");
        }
    }
    
    public void reversePrintln()
    {
        reverseRecursivePrint(list);
        System.out.println();
    }
}