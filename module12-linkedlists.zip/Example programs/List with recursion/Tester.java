public class Tester
{
    public static void main()
    {
        List l = new List();

        for (int x = 1; x < 6; ++x)
            l.insertFirst(x);

        l.println();
        
        l.reversePrintln();

        System.out.println("done");
    }
}