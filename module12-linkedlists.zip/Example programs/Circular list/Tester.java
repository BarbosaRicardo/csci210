public class Tester
{
    public static void main()
    {
        CircularList cl = new CircularList();

        for (int x = 1; x < 6; ++x)
            cl.append(x);

        System.out.println(cl.toString());
    }
}
