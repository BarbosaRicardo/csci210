public class Palindrome
{
    boolean palindrome(String phrase, int left, int right)
    {
        if (left >= right)
            return true;
        return phrase.charAt(left) == phrase.charAt(right) &&
            palindrome(phrase, left + 1, right - 1);
    }
}
